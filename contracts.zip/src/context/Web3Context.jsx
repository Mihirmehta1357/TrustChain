import React, { createContext, useState, useEffect, useCallback } from "react";
import { ethers } from "ethers";
import TrustChainABI from "../artifacts/contracts/TrustChain.sol/TrustChain.json";

export const Web3Context = createContext();

const CONTRACT_ADDRESS = "0xDc64a140Aa3E981100a9becA4E685f962f0cF6C9";

export const Web3Provider = ({ children }) => {
  const [account, setAccount]       = useState("");
  const [contract, setContract]     = useState(null);
  const [provider, setProvider]     = useState(null);
  const [signer, setSigner]         = useState(null);
  const [trustScore, setTrustScore] = useState(null);

  const refreshTrustScore = useCallback(async (addr, c) => {
    if (!addr || !c) return;
    try {
      const userData = await c.users(addr);
      setTrustScore(Number(userData.trustScore));
    } catch (_) {}
  }, []);

  const connectWallet = async () => {
    if (!window.ethereum) {
      alert("Please install MetaMask to use this feature!");
      return;
    }
    try {
      const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
      const addr = accounts[0];
      setAccount(addr);

      const ethersProvider = new ethers.BrowserProvider(window.ethereum);
      setProvider(ethersProvider);

      const ethersSigner = await ethersProvider.getSigner();
      setSigner(ethersSigner);

      const c = new ethers.Contract(CONTRACT_ADDRESS, TrustChainABI.abi, ethersSigner);
      setContract(c);
      console.log("Connected to Wallet:", addr);

      // Auto-register new user — new contract registerUser() takes no args
      try {
        const userCheck = await c.users(addr);
        if (!userCheck.isRegistered) {
          console.log("Auto-registering on blockchain... base score = 50");
          const tx = await c.registerUser();
          await tx.wait();
          console.log("Registered on blockchain!");
        } else {
          console.log("User already registered.");
        }
      } catch (e) {
        console.error("Auto-registration failed", e);
      }

      await refreshTrustScore(addr, c);
    } catch (error) {
      console.error("Wallet connection failed", error);
    }
  };

  useEffect(() => {
    if (window.ethereum?.selectedAddress) connectWallet();

    if (window.ethereum) {
      window.ethereum.on("accountsChanged", (accounts) => {
        if (accounts.length > 0) connectWallet();
        else { setAccount(""); setContract(null); setTrustScore(null); }
      });
    }
  }, []);

  return (
    <Web3Context.Provider value={{ account, connectWallet, contract, provider, signer, trustScore, refreshTrustScore }}>
      {children}
    </Web3Context.Provider>
  );
};
